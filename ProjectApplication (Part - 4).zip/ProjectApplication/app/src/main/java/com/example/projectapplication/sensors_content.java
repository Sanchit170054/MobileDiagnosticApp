package com.example.projectapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;


/**
 * <p> Title: sensors_content Class. </p>
 *
 * <p> Description: This class basically used to show the in-built sensors for diagnosis.
 * This class hold the different aspect of sensors like proximity sensor, accelerometer, gyroscope etc
 * for diagnosis point of view but for this time, this class is not in use</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-08-24 java class which when click just shows the various sensors present in the user's
 * phone
 *
 */

public class sensors_content extends AppCompatActivity {

    public LinearLayout motion, position, light;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensors_content);

        motion = findViewById(R.id.motionSensor_ID);
        position = findViewById(R.id.positionSensor_ID);
        light = findViewById(R.id.lightSensor_ID);


        motion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(sensors_content.this, motions_sensors_content.class);
                startActivity(intent);
            }
        });

        position.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(sensors_content.this, position_sensor_content.class);
                startActivity(intent);
            }
        });

        light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(sensors_content.this, light_sensor.class);
                startActivity(intent);
            }
        });
    }
}
