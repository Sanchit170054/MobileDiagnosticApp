package com.example.projectapplication;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.format.Formatter;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;
import static androidx.core.content.ContextCompat.checkSelfPermission;

/**
 * <p> Title: new_device_info Class. </p>
 *
 * <p> Description: This class is used to fetch the information related to the mobile devic
 * This main purpose of this class is to get the basic information related to the user phone like
 * IMEI number, Network provider etc.</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-08-24 java class used to show the UI for the device information activity
 * @version 1.11	2019-09-28 java class used to show the user's device information in a list view
 *
 */


public class new_device_info extends Fragment {
    View v;
    TextView show;
    ArrayAdapter<String> adapter;
    ArrayList<String> itemList;
    List<String> list = new ArrayList<>();

    List<String> list_internal = new ArrayList<>();
    String serviceType = Context.TELEPHONY_SERVICE;

    @RequiresApi(api = Build.VERSION_CODES.O)
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_new_device_info, null);

        WifiManager manager = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = manager.getConnectionInfo();

        TelephonyManager m_telephonyManager = (TelephonyManager) getActivity().getSystemService(serviceType);
        String version = "ANDROID VERSION : " + Build.VERSION.RELEASE + ".0";
        list.add("\n" + version + "\n");

        String android_ID = "ANDROID ID : " + Settings.System.getString(getActivity().getContentResolver(),
                Settings.Secure.ANDROID_ID);
        list.add("\n" + android_ID + "\n");

        String OS_name = "OS NAME : " + System.getProperty("os.name");
        list.add("\n" + OS_name + "\n");

        String kernel_version = "KERNEL VERSION : " + System.getProperty("os.version");
        list.add("\n" + kernel_version + "\n");

        String number_of_processors = "NUMBER OF PROCESSORS : " + Runtime.getRuntime().availableProcessors();
        list.add("\n" + number_of_processors + "\n");

//        String storage_memory = "TOTAL MEMORY : " + Runtime.getRuntime().maxMemory();
//        list.add("\n" + storage_memory + "\n");
//
//        String fre_memory = "FREE MEMEORY : " + Runtime.getRuntime().freeMemory();
//        list.add("\n" + fre_memory + "\n");
//
//        String used_memory = "USED MEMEORY : " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory());
//        list.add("\n" + used_memory + "\n");

        String version_inc = "BUILD VERSION  : " + Build.VERSION.INCREMENTAL;
        list.add("\n" + version_inc + "\n");

        String version_SDK = "SDK VERSION : " + Build.VERSION.SDK_INT;
        list.add("\n" + version_SDK + "\n");

        String brand = "BRAND : " + Build.BRAND;
        list.add("\n" + brand + "\n");

        String cpu = "CPU TYPE : " + Build.CPU_ABI;
        list.add("\n" + cpu + "\n");

        String hardware = "HARDWARE : " + Build.HARDWARE;
        list.add("\n" + hardware.toUpperCase() + "\n");

        String host = "HOST : " + Build.HOST;
        list.add("\n" + host + "\n");

        String ID = "BUILD NUMBER : " + Build.ID;
        list.add("\n" + ID + "\n");

        String manfctr = "MANUFACTURER : " + Build.MANUFACTURER;
        list.add("\n" + manfctr + "\n");

        String model = "MODEL : " + Build.MODEL;
        list.add("\n" + model + "\n");


        long totalMemory = getTotalInternalMemorySize();
        long free_internal_Memory = getAvailableInternalMemorySize();
        String total_memory = String.valueOf(getTotalInternalMemorySize());
        String message = "\n"+"          INTERNAL STORAGE INFORMATION"+"\n\n\n";

        list.add(message+"TOTAL MEMORY : " +total_memory +" GB"+"\n");

        String freeInternalValue  = String.valueOf(getAvailableInternalMemorySize());
        list.add("\nFREE MEMORY : " +freeInternalValue  +" GB"+"\n");

        long usedInternalValue = totalMemory - free_internal_Memory;
        list.add("\nUSED MEMEORY : "+usedInternalValue+ " GB" +"\n");

        String message1 = "\n"+"                        RAM INFORMATION"+"\n\n\n";
        long totalRamValue = totalRamMemorySize();
        long freeRamValue = freeRamMemorySize();
        long usedRamValue = totalRamValue - freeRamValue;

        String formated_totalram= formatSize(totalRamValue);
        list.add(message1+"TOTAL RAM : "+formated_totalram+"\n");

        String formated_freeram =formatSize(freeRamValue);
        list.add("\nFREE RAM : "+formated_freeram+"\n");

        String formated_usedram = formatSize(usedRamValue);
        list.add("\nUSED RAM : "+formated_usedram+"\n");

        String message3 = "\n"+"          NETWORK OPERATOR INFORMATION"+"\n\n\n";

        String Sim_oprtr = "SIM OPERATOR NAME : " + m_telephonyManager.getNetworkOperatorName();
        list.add(message3+Sim_oprtr + "\n");

        if (checkSelfPermission(getActivity(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(getActivity(), Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_PHONE_STATE}, 1);
        }
        String IMEI = "IMEI NUMBER : " + m_telephonyManager.getDeviceId();
        list.add("\n"+IMEI+"\n");

        String line_number = "SIM OPERATOR NUMBER  : " +m_telephonyManager.getLine1Number();
        list.add("\n"+line_number+"\n");

        String country_ID = "COUNTRY'S CODE : " + m_telephonyManager.getSimCountryIso();
        list.add("\n" + country_ID.toUpperCase() + "\n");
//
//        String type = "TYPE : " + Build.TYPE;
//        list.add("\n" + type + "\n");

        String network_type = "NETWORK TYPE : " + getNetworkTypeString(m_telephonyManager.getNetworkType());
        list.add("\n" + network_type + "\n");


//        String address = "Wi-Fi MAC Address : " + info.getMacAddress();
//        list.add("\n" + address + "\n");

        itemList=new ArrayList<String>(list);
        adapter=new ArrayAdapter<String>(getActivity(), R.layout.list_item,R.id.txtview,itemList);

        ListView listV= v.findViewById(R.id.list1);
        listV.setAdapter(adapter);

        return v;
    }

    private String getNetworkTypeString(int type){
        String typeString = "Unknown";

        switch(type)
        {
            case TelephonyManager.NETWORK_TYPE_EDGE:
                typeString = "EDGE"; break;
            case TelephonyManager.NETWORK_TYPE_CDMA:
                typeString = "3G Network"; break;
            case TelephonyManager.NETWORK_TYPE_GSM:
                typeString = "2G Network"; break;
            case TelephonyManager.NETWORK_TYPE_LTE:
                typeString = "4G LTE"; break;
            case TelephonyManager.NETWORK_TYPE_HSPA:
                typeString = "HSPA"; break;

            default:
                typeString = "UNKNOWN"; break;
        }

        return typeString;
    }

    public static long getTotalInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount();
        long value = (totalBlocks*blockSize)/1024/1024/1024;
        return value;
    }
    public static long getAvailableInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        long avail_value = (availableBlocks*blockSize)/1024/1024/1024;
        return avail_value;
    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private long totalRamMemorySize() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager activityManager = (ActivityManager)getActivity().getSystemService(ACTIVITY_SERVICE);
        activityManager.getMemoryInfo(mi);
        long availableMegs = mi.totalMem;
        return availableMegs;
    }
    private long freeRamMemorySize() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager activityManager = (ActivityManager) getActivity().getSystemService(ACTIVITY_SERVICE);
        activityManager.getMemoryInfo(mi);
        long availableMegs = mi.availMem;

        return availableMegs;
    }

    public static String formatSize(long size) {
        String suffix = null;

        if (size >= 1024) {
            suffix = " KB";
            size /= 1024;
            if (size >= 1024) {
                suffix = " MB";
                size /= 1024;
            }
        }
        StringBuilder resultBuffer = new StringBuilder(Long.toString(size));

        int commaOffset = resultBuffer.length() - 3;
        while (commaOffset > 0) {
            resultBuffer.insert(commaOffset, ',');
            commaOffset -= 3;
        }
        if (suffix != null) resultBuffer.append(suffix);
        return resultBuffer.toString();
    }
}







