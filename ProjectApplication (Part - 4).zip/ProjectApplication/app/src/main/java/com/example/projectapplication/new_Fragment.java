package com.example.projectapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * <p> Title: new_Fragment Class. </p>
 *
 * <p> Description: This is first activity user see when interact with the application,
 * This class basically used to show the various categories of diagnosis like audio, camera, sensors etc .
 * This class hold the different aspect of diagnosis for user's phone.</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-08-24 java class which just shows the layout of different diagnosis
 * @version 1.11    2019-9-28 java class with clickable functionality to show brief about the each category
 *
 */

public class new_Fragment extends Fragment {
    View v;
    Intent intent;
    public LinearLayout audiolayout, cameralayout, networklayout, sensorlayout, hardwarelayout;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_new_, null);
        intent = new Intent(getActivity(), Audio_content.class);
        audiolayout = v.findViewById(R.id.wifi_linearlayout);
        cameralayout = v.findViewById(R.id.camera_layoutID);
        audiolayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                intent = new Intent(getActivity(), Audio_content.class);
                startActivity(intent);

//                Toast.makeText(getActivity(), "Will Come in Next Version", Toast.LENGTH_LONG).show();
            }
        });



        cameralayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                intent = new Intent(getActivity(), camera_content.class);
                startActivity(intent);
            }
        });

        networklayout = v.findViewById(R.id.network_layoutID);
        networklayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getActivity(), network_content.class);
                startActivity(intent);
            }
        });

        sensorlayout = v.findViewById(R.id.sensor_layoutID);
        sensorlayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getActivity(), sensors_content.class);
                startActivity(intent);

                     }
        });

        hardwarelayout = v.findViewById(R.id.hardware_layoutID);
        hardwarelayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getActivity(), hardware_content.class);
                startActivity(intent);
            }
        });


        return v;
    }
}

