package com.example.projectapplication;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.READ_SMS;

/**
 * <p> Title: mobileNetworkDiagnose Class. </p>
 *
 * <p> Description: This class is used to fetch the information related to the mobile networks
 * This main purpose of this class is to diagnose the user's mobile network and show the diagnosis result to the user</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 java class used to diagnose the mobile related information
 *
 */


public class mobileNetworkDIagnose extends AppCompatActivity {
    TelephonyManager tm;
    public int signalValue = 93;
    public ImageView connection_statusIMG;
//    myPhoneStateListener psListener;
    public int signalStrengthValue;
    ArrayAdapter<String> adapter;
    ArrayList<String> itemList;
    List<String> list = new ArrayList<>();
    private static final int EXCELLENT_LEVEL = 75;
    private static final int GOOD_LEVEL = 50;
    private static final int MODERATE_LEVEL = 25;
    private static final int WEAK_LEVEL = 0;

    @RequiresApi(api = Build.VERSION_CODES.O)
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);
    DataBase_Handler DB = new DataBase_Handler(this);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_mobile_network_diagnose);

        connection_statusIMG = findViewById(R.id.connect);

        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            String connected = "Internet Connection : Connected";
            connection_statusIMG.setImageResource(R.drawable.net_connected);
            list.add("\n"+connected+"\n");

            DB.insertData("Mobile Network Test", dayName, date, time, "Pass");

        } else {
            String not_connected = "Internet Connection : Not-Connected";
            connection_statusIMG.setImageResource(R.drawable.not_connected);
            list.add("\n"+not_connected+"\n");

            DB.insertData("Mobile Network Test", dayName, date, time, "Fail");
        }

        tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        String networktype = getNetworkTypeString(tm.getNetworkType());
        list.add("\n"+networktype+"\n");

        String phonetype = getPhoneTypeString(tm.getPhoneType());
        list.add("\n"+phonetype+"\n");


        if(networktype == "Network Type : 2G Network")
        {
            String downloadSpeed = "Download Speed : 114 kbit/s";
            String uploadSpeed = "Upload Speed : 20 kbit/s ";
            list.add("\n"+downloadSpeed +"\n");
            list.add("\n"+uploadSpeed+"\n");
        }
        if(networktype == "Network Type : 3G Network")
        {
            String downloadSpeed = "Download Speed : 7.2 Mbit/s";
            String uploadSpeed = "Upload Speed : 2 Mbit/s";
            list.add("\n"+downloadSpeed +"\n");
            list.add("\n"+uploadSpeed+"\n");
        }
        if(networktype == "Network Type : 4G Network")
        {
            String downloadSpeed = "Download Speed : 299.6 Mbit/s";
            String uploadSpeed = "Upload Speed : 75.4 Mbit/s";
            list.add("\n"+downloadSpeed +"\n");
            list.add("\n"+uploadSpeed+"\n");
        }

        int newSignalValue = signalValue * 2 - 113;

        String signalLevelString = getSignalLevelString(newSignalValue);
        list.add("\n"+signalLevelString+"\n");


        itemList=new ArrayList<String>(list);
        adapter=new ArrayAdapter<String>(this,R.layout.list_item,R.id.txtview,itemList);

        ListView listV= findViewById(R.id.list);
        listV.setAdapter(adapter);

    }

    private String getNetworkTypeString(int type){
        String typeString = "Unknown";

        switch(type)
        {
            case TelephonyManager.NETWORK_TYPE_CDMA:
                typeString = "Network Type : 2G Network"; break;
            case TelephonyManager.NETWORK_TYPE_EDGE:
                typeString = "Network Type : 3G Network"; break;
            case TelephonyManager.NETWORK_TYPE_LTE:
                typeString = "Network Type : 4G Network"; break;
            default:
                typeString = "Network Type : UNKNOWN"; break;
        }

        return typeString;
    }

    private String getPhoneTypeString(int type){
        String typeString = "Unknown";

        switch(type)
        {
            case TelephonyManager.PHONE_TYPE_GSM:
                typeString = "Phone Type : GSM"; break;
            case TelephonyManager.PHONE_TYPE_CDMA:
                typeString = "Phone Type : CDMA"; break;

            default:
                typeString = "Phone Type : UNKNOWN"; break;
        }

        return typeString;
    }


    private String getSignalLevelString(int level) {

        String signalLevelString = "Weak";

        if(level > EXCELLENT_LEVEL)
            signalLevelString = "Signal Health : Excellent";
        else if(level > GOOD_LEVEL)
            signalLevelString = "Signal Health : Good";
        else if(level > MODERATE_LEVEL)
            signalLevelString = "Signal Health : Moderate";
        else if(level > WEAK_LEVEL)
            signalLevelString = "Signal Health : Weak";

        return signalLevelString;
    }

//     tm.listen(psListener,PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);

//    public class myPhoneStateListener extends PhoneStateListener {
//
//
//        public void onSignalStrengthsChanged(SignalStrength signalStrength) {
//            super.onSignalStrengthsChanged(signalStrength);
//            if (signalStrength.isGsm()) {
//                if (signalStrength.getGsmSignalStrength() != 99)
//                    signalStrengthValue = signalStrength.getGsmSignalStrength() * 2 - 113;
//                else
//                    signalStrengthValue = signalStrength.getGsmSignalStrength();
//            } else {
//                signalStrengthValue = signalStrength.getCdmaDbm();
//            }
//
//        }
//    }

}
