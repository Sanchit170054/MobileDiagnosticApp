package com.example.projectapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataBase_Handler extends SQLiteOpenHelper {

    public static int database_version = 1;
    public static String database_name = "newDatabase";
    public static String table_name = "recordTable";
    public static String coloumn_id = "id";
    public static String coloumn_TestName= "TestName";
    public static String coloumn_TestDay= "TestDay";
    public static String coloumn_TestDate = "TestDate";
    public static String coloumn_TestTime = "TestTime";
    public static String coloumn_TestResult = "Result";

    public DataBase_Handler(Context context) {
        super(context, database_name, null, database_version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + table_name + "(" + coloumn_id + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + coloumn_TestName + " TEXT," +coloumn_TestDay + " Text," + coloumn_TestDate + " DATETIME DEFAULT CURRENT_DATE,"+ coloumn_TestTime + " DATETIME DEFAULT CURRENT_TIME," +
                coloumn_TestResult + " Text" + ")" );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + table_name);
        onCreate(db);

    }


    public long insertData(String testName, String testDay, String testDate, String testTime, String testResult){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(coloumn_TestName, testName);
        cv.put(coloumn_TestDay, testDay);
        cv.put(coloumn_TestDate, testDate);
        cv.put(coloumn_TestTime, testTime);
        cv.put(coloumn_TestResult, testResult);
        long id = db.insert(table_name,null, cv);
        db.close();
        Log.d("myTag", "This is my message..............................." +id+".............");
        return id;
    }


    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor res = db.rawQuery("select * from "+table_name,null);
        String querry = "Select * from "+table_name;
        Cursor cursor = db.rawQuery(querry, null);
        return cursor;

    }


    public Cursor getAllData(String date){
        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor res = db.rawQuery("select * from "+table_name,null);
//        String querry = "Select * from "+table_name + "where TestDate = '" +date+"'";
        Cursor cursor = db.rawQuery("Select * from "+table_name +" where TestDate = '" +date+"'", null);
        return cursor;

    }

//    public int deleteData(String tesDate)
//    {
//        SQLiteDatabase db = this.getWritableDatabase();
//       String[] whereArgs = {tesDate};
//       String querry = "select * from "+table_name;
//        int count = db.delete(table_name,coloumn_TestDate + "= ?", whereArgs);
//        return  count;
////
//    }

}