package com.example.projectapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

/**
 * <p> Title: network_content Class. </p>
 *
 * <p> Description: This class basically used to show the content of network for the diagnosis.
 * This class hold the different aspect of network like mobile network, wifi, bluetooth for further diagnosis.</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 java class which when click just shows the network related content for diagnosis
 *
 */


public class network_content extends AppCompatActivity {

    public LinearLayout wifi, mobile_Network, bluetooth;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_network_content);
        wifi = findViewById(R.id.wifi_linearlayout);
        bluetooth = findViewById(R.id.bluetooth_ID);
        mobile_Network = findViewById(R.id.mobileNetwork_ID);

        wifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(network_content.this, wifi_loader.class);
                startActivity(intent);
            }
        });

        mobile_Network.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(network_content.this, mobile_network_loader.class);
                startActivity(intent);
            }
        });

        bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(network_content.this, bluetoothDiagnose.class);
                startActivity(intent);
            }
        });

    }
}
