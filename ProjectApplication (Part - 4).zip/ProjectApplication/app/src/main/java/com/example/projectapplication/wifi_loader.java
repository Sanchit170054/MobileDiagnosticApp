package com.example.projectapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Timer;
import java.util.TimerTask;

/**
 * <p> Title: wifi_loader Class. </p>
 *
 * <p> Description: This class is used to show the concept of loading while at the time of click
 * for wifi related information. This class just call before the actual wifi diagnostic class</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 Java class used to give a professional view for the wifi diagnosis
 *
 */

public class wifi_loader extends AppCompatActivity {

    TextView message;
    ProgressBar load;
    public CoordinatorLayout coordinatorLayout;
    int SPLASH_TIME = 3000;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_loader);

        load = findViewById(R.id.load_data);
        message = findViewById(R.id.message_show);
        message.setText("Diagnosing Your Wifi..");
        Toast.makeText(getApplicationContext(), "will take some seconds..", Toast.LENGTH_SHORT).show();

//        playProgress();

        //Code to start timer and take action after the timer ends
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                  Intent mySuperIntent = new Intent(wifi_loader.this, WifiDiagnose.class);

                    startActivity(mySuperIntent);
                    //This 'finish()' is for exiting the app when back button pressed from Home page which is ActivityHome
                    finish();

                    Toast.makeText(getApplicationContext(), "Diagnosis Complete..", Toast.LENGTH_SHORT).show();
            }
        },
                SPLASH_TIME);


    }


}