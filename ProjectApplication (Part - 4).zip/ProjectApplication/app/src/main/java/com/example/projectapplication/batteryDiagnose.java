package com.example.projectapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;


/**
 * <p> Title: batteryDiagnose Class. </p>
 *
 * <p> Description: This class is used to fetch the information related to the battery and will call
 * after the battery_loader class. This main purpose of this class is to diagnose the battery and show the diagnosis result
 * into a kind of list view</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 java class used to diagnose the battery and show the relevant information to the user
 *
 */

public class batteryDiagnose extends Activity {

    TextView health, percent, plugedValue, chargingstatus, technology1, temprature,capacity1, voltage1;
    ImageView battery_show;
   IntentFilter intentfilter;
    int deviceHealth;
    String currentBatteryHealth = "Battery Health ";
    int batteryLevel;

    @RequiresApi(api = Build.VERSION_CODES.O)
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);
    DataBase_Handler DB = new DataBase_Handler(this);

    private BroadcastReceiver broadcastreceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            deviceHealth = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);
            health = findViewById(R.id.battery_health);
            battery_show = findViewById(R.id.battery_icon);
            if (deviceHealth == BatteryManager.BATTERY_HEALTH_COLD) {


                    health.setText("\n"+currentBatteryHealth + " = Cold");
            }

            if (deviceHealth == BatteryManager.BATTERY_HEALTH_DEAD) {

                health.setText("\n"+currentBatteryHealth + " = Dead");
            }

            if (deviceHealth == BatteryManager.BATTERY_HEALTH_GOOD) {

                health.setText("\n"+currentBatteryHealth + " = Good");

            }

            if (deviceHealth == BatteryManager.BATTERY_HEALTH_OVERHEAT) {

                health.setText("\n"+currentBatteryHealth + " = OverHeat");
            }

            if (deviceHealth == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) {

                health.setText("\n"+currentBatteryHealth + " = Over voltage");
            }

            if (deviceHealth == BatteryManager.BATTERY_HEALTH_UNKNOWN) {

                health.setText("\n"+currentBatteryHealth + " = Unknown");
            }
            if (deviceHealth == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE) {

                health.setText("\n"+currentBatteryHealth + " = Unspecified Failure");
            }

            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

            percent = findViewById(R.id.battery_pct);
            if (level != -1 && scale != -1) {
                int batteryPct = (int) ((level / (float) scale) * 100f);
                percent.setText("\n"+"Battery" +"\nPercentage: " + batteryPct + "%");
                DB.insertData("Battery Test", dayName, date, time, "Pass");

                if(batteryPct >= 70)
                {
                    battery_show.setImageResource(R.drawable.battery80);
                }
                else if(batteryPct > 50 || batteryPct < 70)
                {
                    battery_show.setImageResource(R.drawable.battery60);
                }
                else if(batteryPct > 30 || batteryPct <= 50)
                {
                    battery_show.setImageResource(R.drawable.battery50);
                }
                else if(batteryPct <= 30)
                {
                    battery_show.setImageResource(R.drawable.battery20);
                }
            }




            int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            int pluggedLbl = R.string.battery_plugged_none;

            switch (plugged) {
                case BatteryManager.BATTERY_PLUGGED_WIRELESS:
                    pluggedLbl = R.string.battery_plugged_wireless;
                    break;

                case BatteryManager.BATTERY_PLUGGED_USB:
                    pluggedLbl = R.string.battery_plugged_usb;
                    break;

                case BatteryManager.BATTERY_PLUGGED_AC:
                    pluggedLbl = R.string.battery_plugged_ac;
                    break;

                default:
                    pluggedLbl = R.string.battery_plugged_none;
                    break;
            }

            plugedValue = findViewById(R.id.plug_type);
            plugedValue.setText("\n"+getString(pluggedLbl));


            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            int statusLbl = R.string.battery_status_discharging;

            switch (status) {
                case BatteryManager.BATTERY_STATUS_CHARGING:
                    statusLbl = R.string.battery_status_charging;
                    battery_show.setImageResource(R.drawable.battery_charging);


                    break;

                case BatteryManager.BATTERY_STATUS_DISCHARGING:
                    statusLbl = R.string.battery_status_discharging;
                    break;

                case BatteryManager.BATTERY_STATUS_FULL:
                    statusLbl = R.string.battery_status_full;
                    break;

                case BatteryManager.BATTERY_STATUS_UNKNOWN:
                    statusLbl = -1;
                    break;

                case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                default:
                    statusLbl = R.string.battery_status_discharging;
                    break;
            }

            chargingstatus = findViewById(R.id.charge_status);
            if (statusLbl != -1) {
                chargingstatus.setText("\n"+"Charging Status : " + getString(statusLbl));

            }

            technology1 = findViewById(R.id.technology_type);
            if (intent.getExtras() != null) {
                String technology = intent.getExtras().getString(BatteryManager.EXTRA_TECHNOLOGY);

                if (!"".equals(technology)) {
                    technology1.setText("\n"+"Technology : " + technology);
                }
            }

            temprature = findViewById(R.id.battery_temp);
            int temperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            if (temperature > 0) {
                float temp = ((float) temperature) / 10f;
                temprature.setText("\n"+"Battery Temperature : " + temp + "°C");
            }
//
            voltage1 = findViewById(R.id.battery_voltage);
            int voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);

            if (voltage > 0) {

                voltage1.setText("\n"+"Voltage : " + voltage + " mV");
            }
//
            capacity1 = findViewById(R.id.battery_capacity);
            long capacity = getBatteryCapacity(batteryDiagnose.this);
            if (capacity > 0) {
                capacity1.setText("\n"+"Capacity : " + capacity + " mAh");
            }

            else {

                    DB.insertData("Battery Test", dayName, date, time, "Fail");

                Toast.makeText(getApplicationContext(), "No Battery present", Toast.LENGTH_SHORT).show();
            }


        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battery_diagnose);

        intentfilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);

                batteryDiagnose.this.registerReceiver(broadcastreceiver, intentfilter);
//

//        batteryDiagnose.this.registerReceiver(broadcastreceiver, intentfilter);
//        adapter=new ArrayAdapter<String>(this,R.layout.list_item,R.id.txtview,itemList);
//
//        ListView listV=(ListView)findViewById(R.id.list);
//        listV.setAdapter(adapter);



    }

    public long getBatteryCapacity(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            BatteryManager mBatteryManager = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            Long chargeCounter = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            Long capacity = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

            if (chargeCounter != null && capacity != null) {
                long value = (long) (((float) chargeCounter / (float) capacity));
                return value;
            }
        }

        return 0;
    }


}
