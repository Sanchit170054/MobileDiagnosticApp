package com.example.projectapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Set;

public class bluetoothDiagnose extends AppCompatActivity {


    /**
     * <p> Title: bluetoothDiagnose Class. </p>
     *
     * <p> Description: This class is used to fetch the information related to the bluetooth
     * This main purpose of this class is to diagnose the bluetooth along with its some attributes
     * and show the diagnosis result to the user</p>
     *
     * <p> Copyright: Sanchit © 2019 </p>
     *
     * @author Sanchit
     *
     * @version 1.10	2019-09-28 java class used to diagnose the bluetooth related information
     *
     */

    @RequiresApi(api = Build.VERSION_CODES.O)
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);
    DataBase_Handler DB = new DataBase_Handler(this);

    public static final int REQUEST_ENABLE_BT = 12;
    public TextView connect_status, bluetoothAdapter, bluetooth_Name, devicePaired;
    public BluetoothAdapter adapter;
    ImageView b_icon;
    public boolean state = false;
    BluetoothAdapter bluetooth;
    public Button btn1;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bluetooth_diagnose);

        connect_status = findViewById(R.id.connection_status);
        bluetooth_Name = findViewById(R.id.bluetooth_name);
        devicePaired = findViewById(R.id.previous_pair);
        bluetoothAdapter = findViewById(R.id.bluetooth_adapter);
        b_icon = findViewById(R.id.bluetooth_connect);

//        Intent bluetoothPicker = new Intent("android.bluetooth.devicepicker.action.LAUNCH");
//        startActivity(bluetoothPicker);
//        startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));


//        btn1 = (Button)findViewById(R.id.btn);
//        btn1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
//                registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
//
//            }
//        });
        bluetooth = BluetoothAdapter.getDefaultAdapter();
        if (!bluetooth.isEnabled()) {
            connect_status.setText("\nBluetooth Status : Disabled");

            DB.insertData("Bluetooth Test", dayName, date, time, "Fail");

            state = true;
        } else if (bluetooth.isEnabled()) {
            connect_status.setText("\nBluetooth Status : Enabled");
            String address = bluetooth.getAddress();
            String name = bluetooth.getName();
            System.out.println(name + " : " + address);

            DB.insertData("Bluetooth Test", dayName, date, time, "Pass");

            state = false;
        }

        setBluetoothData();

        if (!bluetooth.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        connect_status.setText("");
        setBluetoothData();
    }

    public void setBluetoothData() {

        // Getting the Bluetooth adapter
        adapter = BluetoothAdapter.getDefaultAdapter();

        bluetoothAdapter.setText("Adapter : "+adapter.toString());
        bluetooth_Name.setText("Bluetooth Name : "+adapter.getName());

//        connect_status.append("\nAdapter: " + adapter.toString() + "\n\nName: " + adapter.getName() + "\nAddress: " + adapter.getAddress());

        // Check for Bluetooth support in the first place
        // Emulator doesn't support Bluetooth and will return null

        if (adapter == null) {
            Toast.makeText(this, "Bluetooth NOT supported. Aborting.",
                    Toast.LENGTH_LONG).show();
        }

        // Starting the device discovery
//        connect_status.append("\n\nStarting discovery...");
        adapter.startDiscovery();
//        connect_status.append("\nDone with discovery...\n");

        // Listing paired devices
//        connect_status.append("\nDevices Pared:");
        Set<BluetoothDevice> devices = adapter.getBondedDevices();
        for (BluetoothDevice device : devices) {
            devicePaired.append("Founded device : " + device.getName() + "\nAddress : " + device.getAddress()+"\n");
        }
    }

//    private BroadcastReceiver mBroadcastReceiver3 = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            final String action = intent.getAction();
////            Log.d(TAG, "onReceive: ACTION FOUND.");
//
//            if (action.equals(BluetoothDevice.ACTION_FOUND)){
//                BluetoothDevice device = intent.getParcelableExtra (BluetoothDevice.EXTRA_DEVICE);
////                mBTDevices.add(device);
//                connect_status.setText("onReceive: " + device.getName() + ": " + device.getAddress());
//                 }
//        }
//    };


}