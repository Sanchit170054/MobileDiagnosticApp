package com.example.projectapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;


/**
 * <p> Title: hardware_content Class. </p>
 *
 * <p> Description: This class basically used to show the in-built feature related to the hardware for diagnosis.
 * This class hold the different aspect of hardware like battery, display, touch etc. for the diagnosis point of view.
 * This class will show all the required content at the time of the call</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 java class which when click just shows the hardware based content for diagnosis
 *
 */

public class hardware_content extends AppCompatActivity {

    public LinearLayout batteryLayout, mobile_display, touch_screen, mobile_backlight, multi_touch, vibration, volume;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_content);

        batteryLayout = findViewById(R.id.battery_layoutID);
        batteryLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(hardware_content.this, battery_loader.class);
                startActivity(intent);
            }
        });

        mobile_display = findViewById(R.id.display_test);
        mobile_display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Will Come in Next Version", Toast.LENGTH_LONG).show();

            }
        });


        touch_screen = findViewById(R.id.touch_test);
        touch_screen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Will Come in Next Version", Toast.LENGTH_LONG).show();

            }
        });


        mobile_backlight = findViewById(R.id.backlight_ID);
        mobile_backlight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Will Come in Next Version", Toast.LENGTH_LONG).show();

            }
        });


        multi_touch = findViewById(R.id.multi_touch_ID);
        multi_touch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Will Come in Next Version", Toast.LENGTH_LONG).show();

            }
        });


        vibration = findViewById(R.id.vibration_ID);
        vibration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Will Come in Next Version", Toast.LENGTH_LONG).show();

            }
        });


        volume = findViewById(R.id.volume_ID);
        volume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Will Come in Next Version", Toast.LENGTH_LONG).show();

            }
        });
    }
}
