package com.example.projectapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Surface;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

import static com.example.projectapplication.R.color.colorRed;
import static com.example.projectapplication.R.color.colorWhite;
import static com.example.projectapplication.R.color.material_grey_100;
import static com.example.projectapplication.R.color.material_grey_50;

public class position_sensor_content extends AppCompatActivity implements SensorEventListener {

    private float[] mGravity = new float[3];
    private float[] mGeomagnetic = new float[3];
    private float[] R1 = new float[9];
    private float[] I1 = new float[9];
    final float alpha = 0.97f;


    @RequiresApi(api = Build.VERSION_CODES.O)
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);
    DataBase_Handler DB = new DataBase_Handler(this);

    private float azimuth;
    private float azimuthFix;

    TextView orXAXIS, orYAXIS, orZAXIS, magXAXIS, magYAXIS, magZAXIS, proximityValue;
    SensorManager sensorManager;
    ImageView chnage_bg;
    Sensor orientation, magnetormer, proximity;
    DecimalFormat df = new DecimalFormat("#.#####");
    Button Orientation_info, magnetometer_info, proximity_info;
    AlertDialog.Builder builder;

    private Compass compass;
    private ImageView arrowView;
    private TextView sotwLabel;  // SOTW is for "side of the world"
    private float currentAzimuth;
    private SOTWFormatter sotwFormatter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_position_sensor_content);

        orXAXIS = findViewById(R.id.or_x_axis);
        orYAXIS = findViewById(R.id.or_y_axis);
        orZAXIS = findViewById(R.id.or_z_axis);

        magXAXIS = findViewById(R.id.mag_x_axis);
        magYAXIS = findViewById(R.id.mag_y_axis);
        magZAXIS = findViewById(R.id.mag_z_axis);

//        magXAXIS = findViewById(R.id.mag_x_axis);
//        magYAXIS = findViewById(R.id.mag_y_axis);
//        magZAXIS = findViewById(R.id.mag_z_axis);

        proximityValue = findViewById(R.id.p_axisValue);
        chnage_bg = findViewById(R.id.proxy_backgroudn);

        Orientation_info = findViewById(R.id.orientation_info);
        magnetometer_info = findViewById(R.id.mag_info);
        proximity_info = findViewById(R.id.proxy_info);

        sotwFormatter = new SOTWFormatter(this);

        arrowView =(ImageView) findViewById(R.id.main_image_hands);
        sotwLabel =(TextView) findViewById(R.id.sotw_label);

        setupCompass();

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        DB.insertData("Position Sensor Test", dayName, date, time, "Pass");

        builder = new AlertDialog.Builder(this);

        proximity = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        if (proximityValue != null) {
            sensorManager.registerListener(position_sensor_content.this, proximity, SensorManager.SENSOR_DELAY_NORMAL);
        } else {
            Toast.makeText(getApplicationContext(), "Proximity Sensor is not present in you device", Toast.LENGTH_LONG).show();
        }


        orientation = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        if (proximityValue != null) {
            sensorManager.registerListener(position_sensor_content.this, orientation, SensorManager.SENSOR_DELAY_NORMAL);
        } else {
            Toast.makeText(getApplicationContext(), "Orientation Sensor is not present in you device", Toast.LENGTH_LONG).show();
        }

        magnetormer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        if (magnetormer != null) {

            sensorManager.registerListener(position_sensor_content.this, magnetormer, SensorManager.SENSOR_DELAY_GAME);
            magnetometer_info.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    builder.setMessage("Name: " + magnetormer.getName() + "\nVendor: " + magnetormer.getVendor() + "\nVersion: " + magnetormer.getVersion()
                            + "\nPower: " + magnetormer.getPower() + " mA" + "\nResolution: " + magnetormer.getResolution() + " m/s²" + "\nMaximum Range: " + magnetormer.getMaximumRange() + " m/s²");
                    //Creating dialog box
                    AlertDialog alert = builder.create();
                    //Setting the title manually
                    alert.setTitle("Sensor Information");
                    alert.show();
                }
            });
        }
         else {
            Toast.makeText(getApplicationContext(), "Orientation Sensor is not present in you device", Toast.LENGTH_LONG).show();
        }



    }

    @Override
    protected void onStart() {
        super.onStart();
        compass.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        compass.stop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        compass.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        compass.stop();
    }

    private void setupCompass() {
        compass = new Compass(this);
        Compass.CompassListener cl = getCompassListener();
        compass.setListener(cl);
    }

    private void adjustArrow(float azimuth) {


        Animation an = new RotateAnimation(-currentAzimuth, -azimuth,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF,
                0.5f);
        currentAzimuth = azimuth;

        an.setDuration(500);
        an.setRepeatCount(0);
        an.setFillAfter(true);

        arrowView.startAnimation(an);
    }

    private void adjustSotwLabel(float azimuth) {
        sotwLabel.setText(sotwFormatter.format(azimuth));
    }


    private Compass.CompassListener getCompassListener() {
        return new Compass.CompassListener() {
            @Override
            public void onNewAzimuth(final float azimuth) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adjustArrow(azimuth);
                        adjustSotwLabel(azimuth);

                    }
                });
            }
        };
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        final Sensor sensor = event.sensor;
        if (sensor.getType() == Sensor.TYPE_PROXIMITY) {
            proximityValue.setText(String.valueOf(df.format(event.values[0])) + " cm");
            if (event.values[0] == 0) {
                chnage_bg.setBackgroundColor(Color.GRAY);
            } else {
                chnage_bg.setBackgroundColor(this.getResources().getColor(colorWhite));
            }
            proximity_info.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    builder.setMessage("Name: " + sensor.getName() + "\nVendor: " + sensor.getVendor() + "\nVersion: " + sensor.getVersion()
                            + "\nPower: " + sensor.getPower() + " mA" + "\nResolution: " + sensor.getResolution() + " m/s²" + "\nMaximum Range: " + sensor.getMaximumRange() + " m/s²");
                    //Creating dialog box
                    AlertDialog alert = builder.create();
                    //Setting the title manually
                    alert.setTitle("Sensor Information");
                    alert.show();
                }
            });

        }

            if (sensor.getType() == Sensor.TYPE_GAME_ROTATION_VECTOR)
            {
                float[] rotMatrix = new float[9];
                float[] rotVals = new float[3];

                SensorManager.getRotationMatrixFromVector(rotMatrix, event.values);
                SensorManager.remapCoordinateSystem(rotMatrix,
                        SensorManager.AXIS_X, SensorManager.AXIS_Y, rotMatrix);

                SensorManager.getOrientation(rotMatrix, rotVals);
                float azimuth = (float) Math.toDegrees(rotVals[0]);
                float pitch = (float) Math.toDegrees(rotVals[1]);
                float roll = (float) Math.toDegrees(rotVals[2]);

                orXAXIS.setText(String.valueOf(df.format(pitch)));
                orYAXIS.setText(String.valueOf(df.format(roll)));
                orZAXIS.setText(String.valueOf(azimuth));

                Orientation_info.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        builder.setMessage("Name: " + "Orientation" + "\nVendor: " + sensor.getVendor() + "\nVersion: " + sensor.getVersion()
                                + "\nPower: " + sensor.getPower() + " mA" + "\nResolution: " + sensor.getResolution() + " m/s²" + "\nMaximum Range: " + sensor.getMaximumRange() + " m/s²");
                        //Creating dialog box
                        AlertDialog alert = builder.create();
                        //Setting the title manually
                        alert.setTitle("Sensor Information");
                        alert.show();
                    }
                });


            }

        if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {



            // mGeomagnetic = event.values;
            mGeomagnetic[0] = alpha * mGeomagnetic[0] + (1 - alpha)
                    * event.values[0];//X
            mGeomagnetic[1] = alpha * mGeomagnetic[1] + (1 - alpha)
                    * event.values[1];//Y
            mGeomagnetic[2] = alpha * mGeomagnetic[2] + (1 - alpha)
                    * event.values[2];//Z


            magXAXIS.setText(Float.toString(mGeomagnetic[0]) + " μT");
            magYAXIS.setText(Float.toString(mGeomagnetic[1])+ " μT");
            magZAXIS.setText(Float.toString(mGeomagnetic[2])+ " μT");

        }
        }



    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
