package com.example.projectapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

import static com.example.projectapplication.R.color.material_grey_50;

/**
 * <p> Title: light_sensor Class. </p>
 *
 * <p> Description: This class is used to test the light sensor of the user's mobile.
 * This main purpose of this class is to check for the sensor which is used to detect the light intensity</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-010-26 java class used to diagnose the light sensor and show the relevant information to the user
 *
 */

public class light_sensor extends AppCompatActivity implements SensorEventListener {

    public ProgressBar lightMeter;
    TextView text_ID;
    Button information;
    Sensor lightSensor;
    SensorManager sensorManager;
    LinearLayout backgroundChanger;
    android.app.AlertDialog.Builder builder;

    @RequiresApi(api = Build.VERSION_CODES.O)
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);
    DataBase_Handler DB = new DataBase_Handler(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_light_sensor);

        lightMeter = findViewById(R.id.lightmeter);
        text_ID = findViewById(R.id.light_value);
        builder = new AlertDialog.Builder(this);
        information = findViewById(R.id.light_information);
        backgroundChanger = findViewById(R.id.chnage_color);

        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        float max = lightSensor.getMaximumRange();
        lightMeter.setMax((int)max);
        if(lightSensor != null)
        {
            DB.insertData("Light Sensor Test", dayName, date, time, "Pass");
            sensorManager.registerListener(light_sensor.this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);

        }
        else {
             DB.insertData("Light Sensor Test", dayName, date, time, "Fail");
            Toast.makeText(getApplicationContext(), "Light Sensor is not available at your device..", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        final Sensor sensor = event.sensor;
        if (sensor.getType() == Sensor.TYPE_LIGHT)
        {
            float currentValue =  event.values[0];
            lightMeter.setProgress((int)currentValue);
            text_ID.setText(String.valueOf(currentValue) + " lx");

            if(event.values[0] <= 3) {
                 backgroundChanger.setBackgroundColor(Color.GRAY);
            }
            else
            {
                backgroundChanger.setBackgroundColor(this.getResources().getColor(R.color.colorWhite));

            }

            information.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    builder.setMessage("Name: " + sensor.getName() + "\nVendor: " + sensor.getVendor() + "\nVersion: " + sensor.getVersion()
                            + "\nPower: " + sensor.getPower() + " mA" + "\nResolution: " + sensor.getResolution() + " lx" + "\nMaximum Range: " + sensor.getMaximumRange() + " lx");
                    //Creating dialog box
                    android.app.AlertDialog alert = builder.create();
                    //Setting the title manually
                    alert.setTitle("Sensor Information");
                    alert.show();
                }
            });
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
