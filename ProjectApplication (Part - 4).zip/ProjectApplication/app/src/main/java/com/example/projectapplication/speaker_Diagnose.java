package com.example.projectapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

public class speaker_Diagnose extends AppCompatActivity {

    Button pass, fail, startTest, btn1, btn2, btn3;
    MediaPlayer mp;
    @SuppressLint("NewApi")
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speaker__diagnose);
        final DataBase_Handler DB = new DataBase_Handler(this);

//        DB.insertData("Speaker", "S", "S", "S","pass" );
        DB.getAllData();
        pass = findViewById(R.id.pass_ID);
        pass.setEnabled(false);
        pass.setVisibility(View.INVISIBLE);
        startTest = findViewById(R.id.start_sound);

        btn1 = findViewById(R.id.button_1);
        btn2 = findViewById(R.id.button_2);
        btn3 = findViewById(R.id.button_3);



        startTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pass.setVisibility(View.VISIBLE);

                mp = MediaPlayer.create(speaker_Diagnose.this, R.raw.count);
                mp.start();


               btn1.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                       btn1.setBackgroundColor(Color.GREEN);
                       btn1.setText("OK");
                   }
               });

                btn2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        btn2.setBackgroundColor(Color.GREEN);
                        btn2.setText("OK");
                    }
                });

                btn3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        btn3.setBackgroundColor(Color.GREEN);
                        btn3.setText("OK");
                    }
                });
                pass.setEnabled(true);

            }
        });



        pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btn1.getText().toString() == "OK" && btn2.getText().toString() == "OK"
                        && btn3.getText().toString() == "OK")
                {
                    pass.setText("Test Pass");
                    pass.setBackgroundColor(Color.GREEN);

                    DB.insertData("Speaker Test", dayName, date, time, "Pass");
                }
                else {
                    pass.setBackgroundColor(Color.RED);
                    pass.setText("Test Fail");
                    DB.insertData("Speaker Test", dayName, date, time, "Fail");
                }

            }
        });



    }
}
