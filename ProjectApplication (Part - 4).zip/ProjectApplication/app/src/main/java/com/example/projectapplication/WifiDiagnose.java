package com.example.projectapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * <p> Title: Wifi_Diagnose Class. </p>
 *
 * <p> Description: This class is used to fetch the information related to the WIFI
 * This main purpose of this class is to diagnose the wifi along with its some necessary information
 * and show the diagnosis result to the user. This class will call after the wifi_loader class</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 java class used to diagnose and its result for the WiFi
 *
 */


public class WifiDiagnose extends AppCompatActivity {

    int NumberOfLevel = 5;
    boolean wifiConnected;
    TextView textView;
    public ImageView wifi_statusIMG;

    ArrayAdapter<String> adapter;
    ArrayList<String> itemList;
    List<String> list = new ArrayList<>();

    @RequiresApi(api = Build.VERSION_CODES.O)
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);
    DataBase_Handler DB = new DataBase_Handler(this);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_diagnose);
        wifi_statusIMG = findViewById(R.id.wifi_connect);
        final WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        textView = findViewById(R.id.txtInput);
        textView.setText("WIFI Network Info");
        ConnectivityManager connMgr = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeInfo = connMgr.getActiveNetworkInfo();
        if (activeInfo != null && activeInfo.isConnected()){ //connected with either mobile or wifi
            wifiConnected = activeInfo.getType() == ConnectivityManager.TYPE_WIFI;
            if (wifiConnected){ //wifi connected
                String connection = "Connected With : Wifi";
                wifi_statusIMG.setImageResource(R.drawable.wifi_connect);
                list.add("\n"+"\n"+connection+"\n");
                DB.insertData("WIFI Network Test", dayName, date, time, "Pass");

            }else {
                String connectiion = "Connected With : Not-Connected";
                wifi_statusIMG.setImageResource(R.drawable.no_wifi);
                list.add("\n"+connectiion+"\n");

                DB.insertData("WIFI Network Test", dayName, date, time, "Fail");
            }

        }


        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                int level = WifiManager.calculateSignalLevel(wifiInfo.getRssi(), NumberOfLevel);
                String connectionLevel = "Connection Strength : "+ level + " out of 5";
                list.add("\n"+connectionLevel+"\n");

                if(level == 0)
                {
                    String signalHealth = "Signal Health : No Signal";
                    list.add("\n"+signalHealth+"\n");
                }
                else if(level > 0 && level < 2)
                {
                    String signalHealth = "Signal Health : Very Low Signal";
                    list.add("\n"+signalHealth+"\n");
                }
                else if(level > 1 && level < 3)
                {
                    String signalHealth = "Signal Health : Weak Signal";
                    list.add("\n"+signalHealth+"\n");
                }
                else if(level > 2 && level < 4)
                {
                    String signalHealth = "Signal Health : Good Signal";
                    list.add("\n"+signalHealth+"\n");
                }

                else {
                    String signalHealth = "Signal Health : Best Signal";
                    list.add("\n"+signalHealth+"\n");
                }

                String networkID = "Network ID : "+ wifiInfo.getNetworkId();
                list.add("\n"+networkID+"\n");

//                networkID.setText("Network ID : "+String.valueOf(wifiInfo.getNetworkId()));
                   String LinkSpeed = "Link Speed : "+ wifiInfo.getLinkSpeed() + "Mbps";
//                LinkSpeed.setText("Link Speed : "+String.valueOf(wifiInfo.getLinkSpeed()) + "Mbps");
                   list.add("\n"+LinkSpeed+"\n");
//               }



        itemList=new ArrayList<String>(list);
        adapter=new ArrayAdapter<String>(this,R.layout.list_item,R.id.txtview,itemList);

        ListView listV= findViewById(R.id.list);
        listV.setAdapter(adapter);
    }


}
