package com.example.projectapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


/**
 * <p> Title: battery_loader Class. </p>
 *
 * <p> Description: This class is used to show the concept of loading while at the time of click
 * for battey related information. This class just call before the actual battery diagnostic class</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 Java class used to give a professional view for the battery diagnosis
 *
 */

public class battery_loader extends AppCompatActivity {

    TextView message;
    ProgressBar load;
    public CoordinatorLayout coordinatorLayout;
    int SPLASH_TIME = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_loader);

        load = findViewById(R.id.load_data);
        message = findViewById(R.id.message_show);
        message.setText("Diagnosing Your Battery..");
        Toast.makeText(getApplicationContext(), "will take few seconds..", Toast.LENGTH_SHORT).show();

//        playProgress();

        //Code to start timer and take action after the timer ends
        new Handler().postDelayed(new Runnable() {
                                      @Override
                                      public void run() {

                                          Intent mySuperIntent = new Intent(battery_loader.this, batteryDiagnose.class);

                                          startActivity(mySuperIntent);
                                          //This 'finish()' is for exiting the app when back button pressed from Home page which is ActivityHome
                                          finish();

                                          Toast.makeText(getApplicationContext(), "Diagnosis Complete..", Toast.LENGTH_SHORT).show();
                                      }
                                  },
                SPLASH_TIME);


    }
}


