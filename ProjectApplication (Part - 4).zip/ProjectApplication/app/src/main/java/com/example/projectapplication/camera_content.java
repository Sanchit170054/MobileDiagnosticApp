package com.example.projectapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;


/**
 * <p> Title: camera_content Class. </p>
 *
 * <p> Description: This class basically used to show the content related to the camera.
 * This class hold the different aspect of camera like front camera, rear camera and flashlight
 * for the diagnosis point of view. When use call this class, it will show all the above mentioned attribute to the
 * user for further processing</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 java class which when click just shows the camera related content for diagnosis purpose
 *
 */

public class camera_content extends AppCompatActivity {

    LinearLayout f_camera, r_camera, flash_layout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_content);

        f_camera = findViewById(R.id.camera_ID);
        f_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(camera_content.this, cameraDiagnose.class);
                startActivity(intent);
            }
        });

        r_camera = findViewById(R.id.read_ID);
        r_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(camera_content.this, cameraDiagnose.class);
                startActivity(intent);
            }
        });


        flash_layout = findViewById(R.id.flash_ID);
        flash_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Will Come in Next Version", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
