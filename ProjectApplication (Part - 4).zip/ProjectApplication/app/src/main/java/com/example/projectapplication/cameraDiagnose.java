package com.example.projectapplication;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * <p> Title: cameraDiagnose Class. </p>
 *
 * <p> Description: This class is used to fetch the information related to the user's camera
 * This main purpose of this class is to diagnose the both the cameras along with its some attributes
 * and show the diagnosis result to the user</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 java class used to diagnose the cameras and show the required information to the
 * user
 *
 */

public class cameraDiagnose extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.O)
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);
    DataBase_Handler DB = new DataBase_Handler(this);

    public Button btn_Camera;
    public ImageView cptr_IMG;
    public TextView textView;
    int finalHeight = 0;
    long finalWidth = 0;

    ArrayAdapter<String> adapter;
    ArrayList<String> itemList;
    List<String> list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_diagnose);

        btn_Camera = findViewById(R.id.capture_btn);
        cptr_IMG = findViewById(R.id.capture_img);
        textView = findViewById(R.id.show_info);
        textView.setVisibility(View.INVISIBLE);

        btn_Camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 0);
                btn_Camera.setBackgroundColor(Color.GREEN);
            }
        });

        itemList=new ArrayList<String>(list);
        adapter=new ArrayAdapter<String>(this,R.layout.list_item,R.id.txtview,itemList);

        ListView listV= findViewById(R.id.list1);
        listV.setAdapter(adapter);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        textView.setVisibility(View.VISIBLE);
        Bitmap bitmap = (Bitmap)data.getExtras().get("data");
        ViewTreeObserver vto = cptr_IMG.getViewTreeObserver();
        vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            public boolean onPreDraw() {
                cptr_IMG.getViewTreeObserver().removeOnPreDrawListener(this);
                finalHeight = cptr_IMG.getMeasuredHeight();
                finalWidth = cptr_IMG.getMeasuredWidth();
                String capture_Day = new SimpleDateFormat("EEE, d MMM yyyy ", Locale.getDefault()).format(new Date());
                itemList.add("\nCapture Day : "+capture_Day+"\n");

                String capture_time = new SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
                itemList.add("\n Time : "+capture_time+"\n");
                itemList.add("\nHeight : " + finalHeight + "\n");
                itemList.add("\nWidth : " + finalWidth+"\n");

                if(!itemList.isEmpty())
                {
                    DB.insertData("Front Camera Test", dayName, date, time, "Pass");
                }
                else
                {
                    DB.insertData("Front Camera Test", dayName, date, time, "Fail");
                }

                return true;
            }
        });


        cptr_IMG.setImageBitmap(bitmap);


    }


}
