package com.example.projectapplication;

import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toolbar;

/**
 * <p> Title: thirdActivity Class. </p>
 *
 * <p> Description: This class is used to handle the navigation bar for the application
 * This class hold the various navigation bar attributes like dashboard, home, about us which when click,
 * users can go to other activities as per their needs</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-09-28 java class used to diagnose the mobile related information
 *
 */

public class thirdActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_third);


            BottomNavigationView navView = findViewById(R.id.nav_view);
            navView.setOnNavigationItemSelectedListener(this);
            loadFragment(new new_Fragment());
        }

        private boolean loadFragment(Fragment fragment)
        {
            if(fragment != null)
            {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
                return true;
            }
            return false;
        }

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            Fragment fragment = null;
            switch (item.getItemId())
            {
                case R.id.navigation_userProfile:
                    fragment = new new_about_us();
                    break;

                case R.id.navigation_dashboard:
                    fragment = new new_Fragment();
                    break;

                 case R.id.navigation_deviceInfo :
                    fragment = new new_device_info();
                     break;
            }
            return loadFragment(fragment);
        }
    }
