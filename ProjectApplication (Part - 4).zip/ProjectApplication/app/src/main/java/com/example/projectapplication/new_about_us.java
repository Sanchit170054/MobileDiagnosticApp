package com.example.projectapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import org.w3c.dom.Text;

/**
 * <p> Title: new_about_us Class. </p>
 *
 * <p> Description: This class is used to show the contact information of the application's developer
 * This main purpose of this class is to provide the developer's information for any query or other thing</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-08-24 java class used to show the developer's contact information
 *
 */


public class new_about_us extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    View v;
    Intent intent;

    public ImageView fImage,iImage,bImage;
    public TextView fContent, iContent, bContent;
    public Toolbar tb;
    public ImageView imageView;

    public ImageView hardware_test;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_new_about_us, null);
//        intent = new Intent(getActivity(), hardwareTest_content.class);
        fImage = v.findViewById(R.id.facebook_logoID);
        iImage = v.findViewById(R.id.instagram_logoID);
        bImage = v.findViewById(R.id.business_logoID);

        fContent = v.findViewById(R.id.facebook_contentID);
        iContent = v.findViewById(R.id.insta_contentID);
        bContent = v.findViewById(R.id.business_contentID);

        imageView = v.findViewById(R.id.optionMenu);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                PopupMenu popup = new PopupMenu(getActivity(), imageView);
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate(R.menu.item_menu, popup.getMenu());

                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
//                        Toast.makeText(getActivity(),"You Clicked : " + item.getTitle(), Toast.LENGTH_SHORT).show();


                        if(item.getTitle() != "Settings")
                        {
                            Intent intent = new Intent(getActivity(), CalenderView.class);
                            startActivity(intent);
                        }
                        return true;


                    }
                });

                popup.show();//showing popup menu
            }
        });//closing the setOnClickListener method

        if(fImage.isPressed() && fContent.isPressed())
        {
            onClick(v);
        }
//

        return v;
    }


    public void onClick(View view) {
        Toast.makeText(getContext(), "pressed", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}