package com.example.projectapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class motions_sensors_content extends AppCompatActivity implements SensorEventListener {

    @RequiresApi(api = Build.VERSION_CODES.O)
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);
    DataBase_Handler DB = new DataBase_Handler(this);

    SensorManager sensorManager;
    Sensor accelerometer, gyroscope, rotationVector, gravity;
    public TextView x_axis, y_axis, z_axis, Gx_axis, Gy_axis, Gz_axis, ro_x_Axis, ro_y_Axis, ro_z_Axis,
                    grXAXIS, grYAXYS, grZAXIS, sensorDetails;

    Button information_Acc, information_gyr, information_rotation, information_gravity;
    AlertDialog.Builder builder;
    DecimalFormat df = new DecimalFormat("#.#####");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motions_sensors_content);

        x_axis = findViewById(R.id.x_axisValue);
        y_axis = findViewById(R.id.y_axisValue);
        z_axis = findViewById(R.id.z_axisValue);

        Gx_axis = findViewById(R.id.g_x_axis);
        Gy_axis = findViewById(R.id.g_y_axis);
        Gz_axis = findViewById(R.id.g_z_axis);

        ro_x_Axis = findViewById(R.id.ro_x_axis);
        ro_y_Axis = findViewById(R.id.ro_y_axis);
        ro_z_Axis = findViewById(R.id.ro_z_axis);

        grXAXIS = findViewById(R.id.gr_x_axis);
        grYAXYS = findViewById(R.id.gr_y_axis);
        grZAXIS = findViewById(R.id.gr_z_axis);

        information_Acc = findViewById(R.id.acc_info);
        information_gyr = findViewById(R.id.gyrscp_info);
        information_rotation = findViewById(R.id.rv_info);
        information_gravity = findViewById(R.id.grav_info);

        builder = new AlertDialog.Builder(this);


        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        DB.insertData("Motion Sensor Test", dayName, date, time, "Pass");

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(accelerometer != null) {
            sensorManager.registerListener(motions_sensors_content.this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);

        }else {
            Toast.makeText(getApplicationContext(), "Accelerometer is not present in you device", Toast.LENGTH_LONG).show();
        }

        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if(gyroscope != null)
        {
            sensorManager.registerListener(motions_sensors_content.this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
        }else {
            Toast.makeText(getApplicationContext(), "Gyroscope is not present in you device", Toast.LENGTH_LONG).show();
        }

        rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if(rotationVector != null)
        {
            sensorManager.registerListener(motions_sensors_content.this, rotationVector, SensorManager.SENSOR_DELAY_NORMAL);
        }else {
            Toast.makeText(getApplicationContext(), "Rotation Vector is not present in you device", Toast.LENGTH_LONG).show();
        }

        gravity = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if(rotationVector != null)
        {
            sensorManager.registerListener(motions_sensors_content.this, gravity, SensorManager.SENSOR_DELAY_NORMAL);
        }else {
            Toast.makeText(getApplicationContext(), "Gravity Sensor is not present in you device", Toast.LENGTH_LONG).show();
        }




    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        final Sensor sensor = event.sensor;

        if(sensor.getType() == Sensor.TYPE_ACCELEROMETER) {

            x_axis.setText(String.valueOf(df.format(event.values[0])) + " m/s²");
            y_axis.setText(String.valueOf(df.format(event.values[1])) + " m/s²");
            z_axis.setText(String.valueOf(df.format(event.values[2])) + " m/s²");
            information_Acc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    builder.setMessage("Name: "+sensor.getName() + "\nVendor: " + sensor.getVendor() + "\nVersion: "+sensor.getVersion()
                    +"\nPower: "+sensor.getPower() + " mA"+ "\nResolution: "+ sensor.getResolution() +" m/s²"+ "\nMaximum Range: "+sensor.getMaximumRange() +" m/s²");
                    //Creating dialog box
                    AlertDialog alert = builder.create();
                    //Setting the title manually
                    alert.setTitle("Sensor Informations");
                    alert.show();
                }
            });

        }

        else if(sensor.getType() == Sensor.TYPE_GYROSCOPE)
        {
            Gx_axis.setText(String.valueOf(df.format(event.values[0])) + " rad/s");
            Gy_axis.setText(String.valueOf(df.format(event.values[1])) + " rad/s");
            Gz_axis.setText(String.valueOf(df.format(event.values[2])) + " rad/s");


            information_gyr.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    builder.setMessage("Name: "+sensor.getName() + "\nVendor: " + sensor.getVendor() + "\nVersion: "+sensor.getVersion()
                            +"\nPower: "+sensor.getPower()+ " mA" + "\nResolution: "+ sensor.getResolution() +" m/s²"+ "\nMaximum Range: "+sensor.getMaximumRange() +" m/s²");
                    //Creating dialog box
                    AlertDialog alert = builder.create();
                    //Setting the title manually
                    alert.setTitle("Sensor Information");
                    alert.show();
                }
            });
        }

        else if(sensor.getType() == Sensor.TYPE_ROTATION_VECTOR)
        {
            ro_x_Axis.setText(String.valueOf(df.format(event.values[0])));
            ro_y_Axis.setText(String.valueOf(df.format(event.values[1])));
            ro_z_Axis.setText(String.valueOf(df.format(event.values[2])));

            information_rotation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    builder.setMessage("Name: "+sensor.getName() + "\nVendor: " + sensor.getVendor() + "\nVersion: "+sensor.getVersion()
                            +"\nPower: "+sensor.getPower()+ " mA" + "\nResolution: "+ sensor.getResolution() +" m/s²"+ "\nMaximum Range: "+sensor.getMaximumRange() +" m/s²");
                    //Creating dialog box
                    AlertDialog alert = builder.create();
                    //Setting the title manually
                    alert.setTitle("Sensor Informations");
                    alert.show();
                }
            });
        }

        else if(sensor.getType() == Sensor.TYPE_GRAVITY)
        {
            grXAXIS.setText(String.valueOf(df.format(event.values[0])) + " m/s²");
            grYAXYS.setText(String.valueOf(df.format(event.values[1])) + " m/s²");
            grZAXIS.setText(String.valueOf(df.format(event.values[2])) + " m/s²");

            information_gravity.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    builder.setMessage("Name: "+sensor.getName() + "\nVendor: " + sensor.getVendor() + "\nVersion: "+sensor.getVersion()
                            +"\nPower: "+sensor.getPower()+ " mA" + "\nResolution: "+ sensor.getResolution() +" m/s²"+ "\nMaximum Range: "+sensor.getMaximumRange() +" m/s²");
                    //Creating dialog box
                    AlertDialog alert = builder.create();
                    //Setting the title manually
                    alert.setTitle("Sensor Informations");
                    alert.show();
                }
            });
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {


    }
}