package com.example.projectapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

/**
 * <p> Title: Audio_content Class. </p>
 *
 * <p> Description: This class basically used to show the in-built feature related to the audio diagnosis.
 * This class hold the different aspect of audio like speaker, headset for the diagnosis point of view but for
 * this time, this class is not in use</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-08-24 java class which when click just shows the audio related content for diagnosis
 *
 */


@RequiresApi(api = Build.VERSION_CODES.O)
public class Audio_content extends AppCompatActivity{

    LinearLayout speaker, audioJack, headset, microPhone;
    LocalDate localDate = LocalDate.now();
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    String date = localDate.format(formatter);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_content);

        speaker = findViewById(R.id.speaker_ID);
        headset = findViewById(R.id.headset_ID);
        microPhone = findViewById(R.id.microphone_ID);

        speaker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Audio_content.this, speaker_Diagnose.class);
                startActivity(intent);
            }
        });

        microPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Audio_content.this, microphone_Diagnose.class);
                startActivity(intent);
            }
        });

        headset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Audio_content.this, headset_diagnose.class);
                startActivity(intent);
            }
        });

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }



//    LocalDate date = LocalDate.now();
//    DayOfWeek dow = date.getDayOfWeek();
//    String dayName = dow.getDisplayName(TextStyle.FULL_STANDALONE, Locale.ENGLISH);
//            System.out.println("FULL_STANDALONE = " + dayName);
}
