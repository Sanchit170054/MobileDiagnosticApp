package com.example.projectapplication;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

/**
 * <p> Title: microphone_diagnose Class. </p>
 *
 * <p> Description: This class is used to test the micorphone of mobile which comes in the caetogory of sound test.
 * This main purpose of this class is to check whether the microphone of user's mobile is properly working or no</p>
 *
 * <p> Copyright: Sanchit © 2019 </p>
 *
 * @author Sanchit
 *
 * @version 1.10	2019-010-26 java class used to diagnose the microphone of user's phone
 *
 */

public class microphone_Diagnose extends AppCompatActivity {

    Button btnPlay, btnRecord, btnStop, TestPass, TestFail;
    MediaRecorder mediaRecorder;
    public static final int RequestPermissionCode = 1;
    MediaPlayer mediaPlayer;
    SeekBar sBar;
    DataBase_Handler DB = new DataBase_Handler(this);

    @SuppressLint("NewApi")
    LocalDate localDate = LocalDate.now();
    @SuppressLint("NewApi")
    String dayName = LocalDate.now().getDayOfWeek().name();
    String time = new java.text.SimpleDateFormat("hh:mm:ss aa", Locale.getDefault()).format(new Date());
    @SuppressLint("NewApi")
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    @SuppressLint("NewApi")
    String date = localDate.format(formatter);

    String pathSave="";
    final int REQUEST_PERMISSION_CODE=1000;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_microphone__diagnose);

        ActivityCompat.requestPermissions(this, new String[]{RECORD_AUDIO},PackageManager.PERMISSION_GRANTED);
        ActivityCompat.requestPermissions(this, new String[]{WRITE_EXTERNAL_STORAGE},PackageManager.PERMISSION_GRANTED);


        btnPlay = findViewById(R.id.play_ID);
        btnRecord = findViewById(R.id.record_ID);
        btnStop = findViewById(R.id.stop_ID);
        sBar = findViewById(R.id.seekbar);

        TestPass = findViewById(R.id.microphone_pass);
        TestFail = findViewById(R.id.microphone_fail);

        mediaRecorder = new MediaRecorder();
        btnRecord.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {

                if(checkPermission()){
                    pathSave= Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+ UUID.randomUUID().toString()+"_recorded.3gp";
                    setUpMediaRecorder();

                    try{
                        mediaRecorder.prepare();
                        mediaRecorder.start();
                    }
                    catch(IOException e){
                        e.printStackTrace();
                    }
                    btnStop.setVisibility(View.VISIBLE);
                    btnRecord.setVisibility(View.INVISIBLE);
//                    stopplay.setVisibility(View.INVISIBLE);

                    Toast.makeText(microphone_Diagnose.this,"Say something to record..!.",Toast.LENGTH_SHORT).show();
                }

                else{
                    requestPermissions();
                }
            }
        });


        btnStop.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View view) {

                                           mediaRecorder.stop();
                                           btnStop.setVisibility(View.INVISIBLE);
                                           btnRecord.setVisibility(View.VISIBLE);
                                           Toast.makeText(microphone_Diagnose.this,"Recording has been stopped....!",Toast.LENGTH_SHORT).show();


//                record.setVisibility(View.VISIBLE);
//                stopplay.setVisibility(View.INVISIBLE);
                                       }
                                   }
        );

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnRecord.setVisibility(View.VISIBLE);
                btnPlay.setVisibility(View.VISIBLE);
                btnStop.setVisibility(View.VISIBLE);
                mediaPlayer=new MediaPlayer();
                try{
                    mediaPlayer.setDataSource(pathSave);
                    mediaPlayer.prepare();
                }
                catch (IOException e){
                    e.printStackTrace();
                }
                mediaPlayer.start();
                Toast.makeText(microphone_Diagnose.this,"Playing..!",Toast.LENGTH_SHORT).show();
            }
        });


        TestPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TestPass.setBackgroundColor(Color.GREEN);
                TestFail.setEnabled(false);

                  DB.insertData("MicroPhone Diagnose", dayName, date, time, "Pass");

            }
        });

        TestFail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TestFail.setBackgroundColor(Color.RED);
                TestPass.setEnabled(false);

                DB.insertData("MicroPhone Diagnose", dayName, date, time, "Fail");

            }
        });

    }

    private void setUpMediaRecorder() {
        mediaRecorder=new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mediaRecorder.setOutputFile(pathSave);
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO},REQUEST_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case REQUEST_PERMISSION_CODE:
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(this,"Permission Granted",Toast.LENGTH_SHORT).show();
                }

                else{
                    Toast.makeText(this,"Permission Denied",Toast.LENGTH_SHORT).show();
                }

                break;
        }
    }

    private boolean checkPermission(){
        int external_record= ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int record_result=ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO);
        return external_record== PackageManager.PERMISSION_GRANTED && record_result==PackageManager.PERMISSION_GRANTED;
    }
}