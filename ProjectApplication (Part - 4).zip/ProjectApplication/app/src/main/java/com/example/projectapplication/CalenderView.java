package com.example.projectapplication;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

public class CalenderView extends AppCompatActivity {

    public Button pickdate, fetchResult, getPDF;
    public TextView setDate, showreprotData;
    static final int READ_BLOCK_SIZE = 100;
    Calendar c;
    DatePickerDialog dp;
    final static String fileName = "data.txt";

    final static String path = Environment.getExternalStorageDirectory().getAbsolutePath() ;
//    final static String TAG = FileHelper.class.getName();

    DataBase_Handler DB = new DataBase_Handler(this);

//    ArrayAdapter<String> adapter;
//    ArrayList<String> itemList;
//    List<String> list = new ArrayList<>();

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender_view);

        pickdate = findViewById(R.id.pickDate);
        setDate = findViewById(R.id.currentSelectedDate);
        showreprotData = findViewById(R.id.showReportData);
        fetchResult = findViewById(R.id.getResult);
        getPDF = findViewById(R.id.generatePDF);


        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDateTime now = LocalDateTime.now();

        setDate.setText(dtf.format(now));

        fetchResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String value  = String.valueOf(setDate.getText());
//
//                Cursor cursor = DB.getData(value);

                Cursor cursor = DB.getAllData(value);
                showreprotData.setText("");
                if(cursor.moveToNext())
                {
                    do{
                        showreprotData.append("Test ID: " +cursor.getString(0)+ "\nTest Name: " +cursor.getString(1) +
                                "\nTest Day: "+cursor.getString(2) +"\nTest Date: " +cursor.getString(3) +
                                "\nTest Time: "+cursor.getString(4)+ "\nTest Result: " + cursor.getString(5)+
                                "\n-----------------------------\n");
                    } while (cursor.moveToNext()) ;
                }

                else {
                    showreprotData.setText("\nNo data found for this "+setDate.getText() +"...!");
                }

                cursor.close();

            }
        });
        pickdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                c = Calendar.getInstance();
                final int day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);


                dp = new DatePickerDialog(CalenderView.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int nyear, int nmonth, int dayOfMonth) {

                        setDate.setText(dayOfMonth + "-" + (nmonth+1) + "-" + nyear);
                    }
                }, day, month, year);
                dp.show();
            }
        });


        getPDF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // write text to file
                     try {
                        FileOutputStream fileout=openFileOutput(fileName, MODE_PRIVATE);
                        OutputStreamWriter outputWriter=new OutputStreamWriter(fileout);
                        outputWriter.write(showreprotData.getText().toString());
                        outputWriter.close();

                        //display file saved message
                        Toast.makeText(getBaseContext(), "File saved successfully!" + getFilesDir() + "/" + fileName,
                                Toast.LENGTH_SHORT).show();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

            }
        });


    }



}